<?php
// Text
$_['text_title']	= '<table><tr><td>Pay with Card</td><td><img src="catalog/view/theme/default/image/master-visa-exp.png" width="100" style="margin-left: 50px;"></td></tr><tr><td>Powered By</td><td><img src="https://woos2s.montypaydev.com/montypaylogo.png" width="125"></td></tr></table>';
$_['text_testmode']	= 'Warning: The payment gateway is in \'Sandbox Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';