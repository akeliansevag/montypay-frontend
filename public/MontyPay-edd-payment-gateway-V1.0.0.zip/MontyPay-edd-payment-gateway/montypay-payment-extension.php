<?php
/*
Plugin Name: MontyPay - Easy Digital Downloads
Description: A payment gateway for Easy Digital Downloads
Version: 1.0.0
Author: MontyPay
Author URI: https://montypay.com
*/
 
 
// registers the gateway
function pw_edd_register_gateway($gateways) {
	$gateways['montypay_gateway'] = array('admin_label' => 'MontyPay Gateway', 'checkout_label' => 'Pay with Card');
	return $gateways;
}
add_filter('edd_payment_gateways', 'pw_edd_register_gateway');
 
function pw_edd_montypay_gateway_cc_form() {

    global $edd_options;

    $methods = $edd_options['methods'];
    if(isset($methods['applepay'])){
        $icons = "master-visa-exp-apple.png";
    }else{
        $icons = "master-visa-exp.png";
    }
	ob_start(); 
	?>
	<style>
		
		table.custom_hosted_table, .custom_hosted_table td {
			border: none !important;
			margin: 0 0 0em;
		}
		.hosted_pay_container_edd {
			position: absolute !important;
		}
        .montypay_edd_icons{
            max-width: 150px !important;
        }
	</style>

<table class="custom_hosted_table">
    <tr>
        <td colspan="2">
            <div>
                <img src="<?php echo WP_PLUGIN_URL;?>/MontyPay-edd-payment-gateway/assets/images/<?php echo $icons; ?>" class="montypay_edd_icons">
            </div>
        </td>
    </tr>
    <tr>
        <td style="width:100px">
            <div class="hosted_pay_container_edd"><?php echo 'Powered By'; ?></div>
        </td>
        <td>
            <div>
                <img src="https://woos2s.montypaydev.com/montypaylogo.png" width="100" class="description_image">
            </div>
        </td>
    </tr>
</table>
	<?php
	echo ob_get_clean();
}
add_action('edd_montypay_gateway_cc_form', 'pw_edd_montypay_gateway_cc_form');

add_action( 'post_updated', 'wpse105892_add_message', 10 );
function wpse105892_add_message() {
    add_filter( 'the_content', 'wpse105892_display_message' );
}

function wpse105892_display_message( $content ) {
    // remove the action once it's run
    remove_action( 'post_updated', 'wpse105892_add_message', 11 );

    $content = "<div class='your-message'>You did it!</div>\n\n" . $content;
    return $content;
}
 
// processes the payment
function pw_edd_process_payment($purchase_data) {

	global $edd_options;


	$currencies_3dotexponent = ['BHD', 'JOD', 'KWD', 'OMR', 'TND'];
    $currencies_noexponent = [
        //'CLP', 
        'VND', 
        'ISK', 
        'UGX', 
        //'KRW', 
        //'JPY'
    ];
 
	if(edd_is_test_mode()) {
		$merchant_key = $edd_options['merchant_key'];
		$merchant_password = $edd_options['merchant_password'];
	} else {
		$merchant_key = $edd_options['merchant_key'];
		$merchant_password = $edd_options['merchant_password'];
	}
 
 
	// check for any stored errors
	$errors = edd_get_errors();
	if(!$errors) {
 
		$purchase_summary = edd_get_purchase_summary($purchase_data);

		$payment = array( 
			'price' => $purchase_data['price'], 
			'date' => $purchase_data['date'], 
			'user_email' => $purchase_data['user_email'],
			'purchase_key' => $purchase_data['purchase_key'],
			'currency' => $edd_options['currency'],
			'downloads' => $purchase_data['downloads'],
			'cart_details' => $purchase_data['cart_details'],
			'user_info' => $purchase_data['user_info'],
			'status' => 'pending'
		);
 
		// record the pending payment
		$payment = edd_insert_payment($payment);

		$customer = array(
            'email' => $purchase_data['user_email'],
        );

        $amount = number_format($purchase_data['price'], 2, '.', '');
        if (in_array(edd_get_currency(), $currencies_noexponent)) {
            $amount = number_format($purchase_data['price'], 0, '.', '');
        }elseif (in_array(edd_get_currency(), $currencies_3dotexponent)) {
            $amount = number_format($purchase_data['price'], 3, '.', '');
        }


        $order_json = array(
            'number' => "$payment",
            'description' => 'Payment Order # ' . $payment . ' in the store ',
            'amount' => $amount, //may troubles
            'currency' => edd_get_currency(),
        );


        $billing_address = array(
            'country' => 'NA',
            'state' => 'NA',
            'city' => 'NA',
            'address' => 'NA',
            'zip' => 'NA',
        );
        

        $array_methods = $edd_options['methods'];//$this->method; //may error
        $methods = array_keys($array_methods);
        if($methods == null){
            $methods = array();
        }

        // print_r($methods);
        // exit;

        $str_to_hash = $payment . $amount . edd_get_currency() . 'Payment Order # ' . $payment .' in the store ' . $merchant_password;
        $hash = sha1(md5(strtoupper($str_to_hash)));

        $main_json = array(
            'merchant_key' => $merchant_key,
            'operation'    => 'purchase', //m subs purchase
            'methods'      => $methods, //$edd_options['methods'], //$methods, // array
            'order'        => $order_json, // array
            'customer'     => $customer, // array
            'billing_address' => $billing_address, // array
            'success_url' => edd_get_confirmation_page_uri(),
            'cancel_url'   => edd_get_failed_transaction_uri(false), //
            'hash'         => $hash
        );



        $getter = curl_init('https://checkout.montypay.com/api/v1/session'); //init curl
        curl_setopt($getter, CURLOPT_POST, 1); //post
        curl_setopt($getter, CURLOPT_POSTFIELDS, json_encode($main_json)); //json
        curl_setopt($getter, CURLOPT_HTTPHEADER, array('Content-Type:application/json')); //header
        curl_setopt($getter, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($getter);
        $httpcode = curl_getinfo($getter, CURLINFO_HTTP_CODE);

		curl_close($getter);

		$response = json_decode((string) $result);

		// payment is complete, it can redirect straight away
		if(isset($response->redirect_url) && $response->redirect_url ){
            wp_redirect( $response->redirect_url, 301 );
			exit;
        }else{
            // file_put_contents('./log_process_payment.log', json_encode($response['errors']), FILE_APPEND);
            $errors = '';
            foreach($response->errors as $value){
                $errors .= $value->error_message.'<br>';
            }
			edd_set_error('invalid_request', $response->error_message.'<br>'.$errors.'<br>'.edd_get_confirmation_page_uri());
			$errors = edd_get_errors();
			$fail = true;

            // $response->error_message.'<br>'.$errors;
			// exit;
        }
		
	} else {
		$fail = true; // errors were detected
	}
 
	if( $fail !== false ) {
		// if errors are present, send the user back to the purchase page so they can be corrected
		edd_send_back_to_checkout('?payment-mode=' . $purchase_data['post_data']['edd-gateway']);
	}
}
add_action('edd_gateway_montypay_gateway', 'pw_edd_process_payment');
 
// adds the settings to the Payment Gateways section
function pw_edd_add_settings($settings) {

	$montypay_gateway_settings = array(
		array(
			'id' => 'montypay_gateway_settings',
			'name' => '<strong>' . __('MontyPay Gateway Settings', 'pw_edd') . '</strong>',
			'desc' => __('Configure the gateway settings', 'pw_edd'),
			'type' => 'header'
		),
		array(
			'id' => 'merchant_key',
			'name' => __('Merchant Key', 'pw_edd'),
			'desc' => __('Enter your Merchant Key, found in your gateway Account Settings', 'pw_edd'),
			'type' => 'text',
			'size' => 'regular'
		),
		array(
			'id' => 'merchant_password',
			'name' => __('Merchant Password', 'pw_edd'),
			'desc' => __('Enter your Merchant Password, found in your gateway Account Settings', 'pw_edd'),
			'type' => 'text',
			'size' => 'regular',
		),
		array(
			'id' => 'methods',
			'name' => 'Methods',
			'desc' => 'Select payment gateway methods.',
			'type' => 'multicheck',
			'size' => 'regular',
			'options' => array(
                'card' => 'Credit Card',
                'applepay' => 'Apple Pay'
            ),
		)
	);

    $settings['montypay_gateway'] = $montypay_gateway_settings;
    return $settings;
	
}
add_filter('edd_settings_gateways', 'pw_edd_add_settings');


function edd_montypay_gateway_settings_sections( $sections ) {
    $sections['montypay_gateway'] = __( 'MontyPay', 'edd-montypay-gateway' );

    return $sections;
}
add_filter( 'edd_settings_sections_gateways', 'edd_montypay_gateway_settings_sections' );


function montypay_callback() {
    // retrieve POST data from IPN request
    $post_data = $_POST;
    
    if(isset($post_data['order_number']) && $post_data['order_number']){
        $order_id = $post_data['order_number'];
    }else{
        $order_id = $post_data['order_id'];
    }
    
    $order_status = edd_get_payment_status( $post_data['order_number']);

	$response = '';
	foreach($post_data as $key => $val){
		$response .= $key . ' : ' . $val .PHP_EOL;
	}

    
	file_put_contents('./wp-content/plugins/MontyPay-edd-payment-gateway/edd_log_callback.log', $response , FILE_APPEND);
	
    // check if payment is successful and update payment status
    if (($post_data['status'] == 'SETTLED' && $post_data['result'] == 'SUCCESS') ) {
        edd_update_payment_status($post_data['order_id'], 'complete');
        // additional code can be added here to process and store other data in the request
    }
    
    if (($post_data['type'] == 'sale' && $post_data['status'] == 'success')) {
        edd_update_payment_status($post_data['order_number'], 'complete');
        // additional code can be added here to process and store other data in the request
    }
    
    if (($post_data['type'] == 'sale' && $post_data['status'] == 'fail')) {
        edd_update_payment_status($post_data['order_number'], 'failed');
        // additional code can be added here to process and store other data in the request
    }
    

    if ($post_data['status'] == 'success' && $post_data['type'] == 'refund') {
        edd_update_payment_status($post_data['order_number'], 'refund');
        exit;
    }
    
    if ($_POST['status'] == 'fail' && $_POST['type'] == 'refund') {
        edd_update_payment_status($post_data['order_number'], 'complete');
        exit;
    }
    

}


function add_montypay_gateway($gateways) {
    $gateways['montypay_gateway'] = array(
          'admin_label' => 'MontyPay Gateway',
          'checkout_label' => 'Pay with Card',
          'supports' => array(),
          'callback_url' => home_url('/index.php?edd-listener=montypay_gateway')
    );
    return $gateways;
}
add_filter('edd_payment_gateways', 'add_montypay_gateway');


function register_montypay_gateway_ipn() {
    if (isset($_GET['edd-listener']) && $_GET['edd-listener'] == 'montypay_gateway') {
        montypay_callback();
    }
}
add_action('init', 'register_montypay_gateway_ipn');