package com.montypay.fluttersdk.eventhandlers

import com.montypay.sdk.core.MontypaySdk
import com.montypay.fluttersdk.helper.toMap
import com.montypay.sdk.MontyPayHomeActivity_
import com.montypay.sdk.model.request.card.MontypayCard
import com.montypay.sdk.model.request.options.MontypaySaleOptions
import com.montypay.sdk.model.request.order.MontypaySaleOrder
import com.montypay.sdk.model.request.payer.MontypayPayer
import com.montypay.sdk.model.response.base.MontypayResponse
import com.montypay.sdk.model.response.base.error.MontypayError
import com.montypay.sdk.model.response.sale.*
import com.google.gson.Gson
import io.flutter.plugin.common.EventChannel
import kotlin.math.sin


class SaleEventHandler: EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            print(
                with(it) {
                    (get("MontypaySaleOrder") as? Map<*, *>)?.let { orderMap ->
                        (get("MontypayPayer") as? Map<*, *>)?.let { payerMap ->
                            (get("MontypayCard") as? Map<*, *>)?.let { cardMap ->
                                (get("auth") as? Boolean)?.let { auth ->

                                    val order = Gson().fromJson(Gson().toJson(orderMap), MontypaySaleOrder::class.java)
                                    val payer = Gson().fromJson(Gson().toJson(payerMap), MontypayPayer::class.java)
                                    val card = Gson().fromJson(Gson().toJson(cardMap), MontypayCard::class.java)

                                    var options:MontypaySaleOptions? = null
                                    (get("MontypaySaleOption") as? Map<*, *>)?.let {
                                        options = Gson().fromJson(Gson().toJson(payerMap), MontypaySaleOptions::class.java)
                                    }

                                    sale(auth = auth, order = order, payer = payer, card = card, saleOptions = options)

                                    "All params are valid"
                                } ?: "Missing 'Boolean' auth parameter"
                            } ?: "Missing 'MontypayCard' parameter"
                        } ?: "Missing 'MontypayPayer' parameter"
                    } ?: "Missing 'MontypaySaleOrder' parameter"
                }
            )
        }

    }

    override fun onCancel(arguments: Any?) {
    }

    fun sale(auth:Boolean, order:MontypaySaleOrder, payer:MontypayPayer, card:MontypayCard, saleOptions:MontypaySaleOptions?){
        MontypaySdk.Adapter.SALE.execute(
            order = order,
            card = card,
            payer = payer,
            termUrl3ds = "https://pay.montypay.sa/",
            options = saleOptions,
            auth = auth,
            callback = object : MontypaySaleCallback {
                override fun onResponse(response: MontypaySaleResponse) {
                    send(mapOf("responseJSON" to response.toMap()))
                    super.onResponse(response)
                }

                override fun onResult(result: MontypaySaleResult) {
                    val res = result.result
                    when (res) {
                        is MontypaySaleDecline -> send(mapOf("decline" to res.toMap()))
                        is MontypaySaleRecurring -> send(mapOf("recurring" to res.toMap()))
                        is MontypaySaleRedirect -> send(mapOf("redirect" to res.toMap()))
                        is MontypaySale3Ds -> send(mapOf("secure3d" to res.toMap()))
                        is MontypaySaleSuccess -> send(mapOf("success" to res.toMap()))
                    }
                }

                override fun onError(error: MontypayError){
                    send(mapOf("error" to error.toMap()))
                }

                override fun onFailure(throwable: Throwable) {
                    send(mapOf("failure" to throwable.toMap()))
                    super.onFailure(throwable)
                }
            }
        )

    }
    private fun send(map:Map<*,*>){
        sink?.success(map)
    }
}