package com.montypay.fluttersdk.eventhandlers

import android.content.Context
import com.montypay.fluttersdk.helper.Helper
import com.montypay.fluttersdk.helper.toMap
import com.montypay.sdk.model.request.order.MontypaySaleOrder
import com.montypay.sdk.model.request.payer.MontypayPayer
import com.montypay.sdk.model.response.base.error.MontypayError
import com.montypay.sdk.model.response.base.result.IMontypayResult
import com.montypay.sdk.model.response.gettransactiondetails.MontypayGetTransactionDetailsSuccess
import com.montypay.sdk.views.montycardpay.MontyCardPay
import com.google.gson.Gson
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.EventChannel
import java.io.Serializable

class CardPayEventHandler(private val context: Context): EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            with(it) {
                (get("MontypaySaleOrder") as? Map<*, *>)?.let { orderMap ->
                    (get("MontypayPayer") as? Map<*, *>)?.let { payerMap ->
                        val order = Gson().fromJson(Gson().toJson(orderMap), MontypaySaleOrder::class.java)
                        val payer = Gson().fromJson(Gson().toJson(payerMap), MontypayPayer::class.java)
                        payWithCard(order, payer)
                    }
                }
            }
        }

    }

    override fun onCancel(arguments: Any?) {

    }

    fun payWithCard(order:MontypaySaleOrder, payer:MontypayPayer){

        val montyCardPay = MontyCardPay()
            .setOrder(order)
            .setPayer(payer)
            .onTransactionFailure { res, data ->
                print("$res $data")
                handleFailure(data!!)
            }.onTransactionSuccess { res, data ->
                print("$res $data")
                handleSuccess(data as? MontypayGetTransactionDetailsSuccess)
            }

        /*
        * Precise way to start card payment (ready to use)
        * */
        montyCardPay.initialize(
            context,
            onError = {
                handleFailure(it)
            },
            onPresent = {
                onPresent()
            }
        )


        /*
        * To get intent of card screen activity to present in your own choice (ready to use)
        * */
//        startActivity(montyCardPay.intent(
//            this,
//            onError = {
//
//            },
//            onPresent = {
//
//            })
//        )


        /*
        * To get fragment of card screen to present in your own choice (ready to use)
        * */
//        montyCardPay.fragment(
//            onError = {
//
//            },
//            onPresent = {
//
//            }
//        )
    }



    private fun onPresent(){
        print("onPresent :)")
        sink?.success(
            mapOf(
                "onPresent" to ":)"
            )
        )
    }

    private fun handleSuccess(response: MontypayGetTransactionDetailsSuccess?){
        print("native.transactionSuccess.data ==> ${response?.toMap()}")
        sink?.success(
            mapOf(
                "success" to response?.toMap()
            )
        )
    }

    private fun handleFailure(error:Any){
        when (error) {
            is  MontypayError -> sink?.success(
                mapOf("error" to error.toMap())
            )
            is Serializable -> sink?.success(
                mapOf("failure" to error.toMap())
            )
            else -> sink?.success(
                mapOf(
                    "error" to mapOf(
                        "result" to "ERROR",
                        "error_code" to 100000,
                        "error_message" to "$error",
                        "errors" to listOf<Map<*,*>>(),
                    )
                )
            )

        }
    }
}