package com.montypay.fluttersdk.helper

import com.montypay.sdk.model.response.base.MontypayResponse
import com.google.gson.Gson
import java.io.Serializable


fun Serializable.toJSON() = Gson().toJson(this)
fun Serializable.toMap() = Gson().fromJson(toJSON(), Map::class.java)
fun Serializable.fromJSON(json:String) = Gson().fromJson(json, this::class.java)


fun MontypayResponse<*>.toMap() : Map<*,*>?{
    return  (this as? MontypayResponse.Error)?.let {
        it.error.toMap()
    } ?: (this as? MontypayResponse.Result)?.let {
        Gson().fromJson(it.jsonObject, Map::class.java)
    }
}