package com.montypay.fluttersdk.eventhandlers

import com.montypay.sdk.core.MontypaySdk
import com.montypay.fluttersdk.helper.toMap
import com.montypay.sdk.model.response.base.error.MontypayError
import com.montypay.sdk.model.response.gettransactionstatus.MontypayGetTransactionStatusCallback
import com.montypay.sdk.model.response.gettransactionstatus.MontypayGetTransactionStatusResponse
import com.montypay.sdk.model.response.gettransactionstatus.MontypayGetTransactionStatusResult
import com.montypay.sdk.model.response.gettransactionstatus.MontypayGetTransactionStatusSuccess
import io.flutter.plugin.common.EventChannel


class GetTransactionStatusEventHandler: EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            print(
                with(it) {
                    (get("transactionId") as? String)?.let { txnId ->
                        (get("payerEmail") as? String)?.let { payerEmail ->
                            (get("cardNumber") as? String)?.let { cardNumber ->

                                txnStatus(payerEmail = payerEmail, cardNumber = cardNumber, transactionId = txnId)

                                "All params are valid"
                            } ?: "Missing 'cardNumber' parameter"
                        } ?: "Missing 'MontypayPayer' parameter"
                    } ?: "Missing 'transactionId' parameter"
                }
            )
        }

    }

    override fun onCancel(arguments: Any?) {
    }

    fun txnStatus(payerEmail:String, cardNumber:String, transactionId:String){
        MontypaySdk.Adapter.GET_TRANSACTION_STATUS.execute(
            payerEmail = payerEmail,
            cardNumber = cardNumber,
            transactionId = transactionId,
            callback = object : MontypayGetTransactionStatusCallback {
                override fun onResponse(response: MontypayGetTransactionStatusResponse) {
                    send(mapOf("responseJSON" to response.toMap()))
                    super.onResponse(response)
                }

                override fun onResult(result: MontypayGetTransactionStatusResult) {
                    val res = result.result
                    when (res) {
                        is MontypayGetTransactionStatusSuccess -> send(mapOf("success" to res.toMap()))
                    }
                }

                override fun onError(error: MontypayError){
                    send(mapOf("error" to error.toMap()))
                }

                override fun onFailure(throwable: Throwable) {
                    send(mapOf("failure" to throwable.toMap()))
                    super.onFailure(throwable)
                }
            }
        )

    }

    private fun send(map:Map<*,*>){
        sink?.success(map)
    }
}