package com.montypay.fluttersdk.methodhandlers

import android.content.Context
import com.montypay.fluttersdk.ENABLE_DEBUG
import com.montypay.sdk.core.MontypaySdk
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel


class ConfigMethodHandler(private val context:Context, private val call:MethodCall, private val result: MethodChannel.Result) {

    fun handle(){
        (call.arguments as? List<*>)?.let {
            with(it) {
                (get(0) as? String)?.let { key ->
                    (get(1) as? String)?.let { password ->
                        MontypaySdk.init(context, key, password, "https://api.montypay.com/post")
                        (get(2) as? Boolean)?.let { enableDebug ->
                            ENABLE_DEBUG = enableDebug
                            if(ENABLE_DEBUG)
                                MontypaySdk.enableDebug()
                            else
                                MontypaySdk.disableDebug()
                        }
                    }
                }
            }
        }
    }

}