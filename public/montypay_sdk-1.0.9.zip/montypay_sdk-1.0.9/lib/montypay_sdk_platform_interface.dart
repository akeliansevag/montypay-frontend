import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'montypay_sdk_method_channel.dart';

abstract class MontypaySdkPlatform extends PlatformInterface {
  /// Constructs a MontypaySdkPlatform.
  MontypaySdkPlatform() : super(token: _token);

  static final Object _token = Object();

  static MontypaySdkPlatform _instance = MethodChannelMontypaySdk();

  /// The default instance of [MontypaySdkPlatform] to use.
  ///
  /// Defaults to [MethodChannelMontypaySdk].
  static MontypaySdkPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [MontypaySdkPlatform] when
  /// they register themselves.
  static set instance(MontypaySdkPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }


  Future<bool> config(String key,String password, bool enableDebug) {
    throw UnimplementedError('config() has not been implemented.');
  }
}
