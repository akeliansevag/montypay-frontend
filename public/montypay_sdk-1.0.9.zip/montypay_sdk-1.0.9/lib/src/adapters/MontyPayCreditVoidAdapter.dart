
import 'dart:convert';

import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/BaseAdapter.dart';
import 'package:montypay_sdk/src/Helpers.dart';

class MontyPayCreditVoidAdapter extends BaseAdapter{

  // transactionId = selectedTransaction.id,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // amount = amount,
  execute({
    required String transactionId,
    required String payerEmail,
    required String cardNumber,
    required double? amount,
    required CreditVoidResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }){

    final params = {
      "transactionId" : transactionId,
      "payerEmail" : payerEmail,
      "cardNumber" : cardNumber,
      "amount" : amount,
    };

    startCreditVoid(params).listen((event) {
      Log(event);
      MontypayCreditVoidResult(event).triggerCallbacks(onResponse, onResponseJSON: onResponseJSON, );
    });

    Log("[MontypayCreditVoidAdapter.execute][Params] ${jsonEncode(params)}");
  }
}