
import 'package:montypay_sdk/montypay_sdk.dart';

class BaseResponseCallback{
  final Function(MontypayError result) error;

  BaseResponseCallback({
    required this.error
  });
}