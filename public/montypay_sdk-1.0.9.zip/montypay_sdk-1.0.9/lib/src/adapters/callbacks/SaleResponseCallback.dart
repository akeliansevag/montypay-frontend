
import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';

class SaleResponseCallback extends BaseResponseCallback{
  final Function(MontypaySaleSuccess result) success;
  final Function(MontypaySaleDecline result) decline;
  final Function(MontypaySaleRecurring result) recurring;
  final Function(MontypaySaleRedirect result) redirect;
  final Function(MontypaySale3DS result) secure3d;

  SaleResponseCallback({
    required this.success,
    required this.decline,
    required this.recurring,
    required this.redirect,
    required this.secure3d,
    required super.error
  });
}