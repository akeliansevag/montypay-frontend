
import 'dart:convert';

import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/BaseAdapter.dart';
import 'package:montypay_sdk/src/Helpers.dart';

class MontyPayGetTransactionDetailsAdapter extends BaseAdapter{

  // transactionId = selectedTransaction.id,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // amount = amount,
  execute({
    required String transactionId,
    required String payerEmail,
    required String cardNumber,
    required TransactionDetailsResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }){


    final params = {
      "transactionId" : transactionId,
      "payerEmail" : payerEmail,
      "cardNumber" : cardNumber,
    };

    startTransactionsDetail(params).listen((event) {
      Log(event);
      MontypayTransactionDetailResult(event).triggerCallbacks(onResponse, onResponseJSON: onResponseJSON);
    });

    Log("[MontypayTransactionDetailAdapter.execute][Params] ${jsonEncode(params)}");
  }
}