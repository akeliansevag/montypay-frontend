
import 'dart:convert';

import 'package:montypay_sdk/src/adapters/BaseAdapter.dart';

import '../../montypay_sdk.dart';
import 'package:montypay_sdk/src/Helpers.dart';

class MontyPaySaleAdapter extends BaseAdapter{

  execute({
    required MontypaySaleOrder order,
    required MontypayCard card,
    required MontypayPayer payer,
    MontypaySaleOption? saleOption,
    required bool isAuth,
    required SaleResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }){

    final params = {
      card.runtimeType.toString() : card.toJson(),
      order.runtimeType.toString() : order.toJson(),
      payer.runtimeType.toString() : payer.toJson(),
      "auth" : isAuth,
      if(saleOption != null)
        card.runtimeType.toString() : saleOption.toJson(),
    };

    startSale(params).listen((event) {
      Log(event);
      MontypaySaleResult(event).triggerCallbacks(onResponse, onResponseJSON: onResponseJSON, onFailure: onFailure);
    });

    Log("[MontypaySaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}