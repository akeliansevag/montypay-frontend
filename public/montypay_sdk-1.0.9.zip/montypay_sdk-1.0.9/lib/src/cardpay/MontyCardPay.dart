import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/callbacks/CardPayResponseCallback.dart';
import 'package:flutter/cupertino.dart';
import 'package:montypay_sdk/src/Helpers.dart';

class MontyCardPay{
  Function(MontypayTransactionDetailsSuccess response)? _onTransactionFailure;
  Function(MontypayTransactionDetailsSuccess response)? _onTransactionSuccess;
  Function(dynamic)? _onError;
  Function(BuildContext)? _onPresent;

  MontypaySaleOrder? _order;
  MontypayPayer? _payer;

  MontyCardPay setOrder(MontypaySaleOrder order){
    _order = order;
    return this;
  }

  MontyCardPay setPayer(MontypayPayer payer){
    _payer = payer;
    return this;
  }

  MontyCardPay onTransactionFailure(Function(MontypayTransactionDetailsSuccess response) callback){
    _onTransactionFailure = callback;
    return this;
  }

  MontyCardPay onTransactionSuccess(Function(MontypayTransactionDetailsSuccess response) callback){
    _onTransactionSuccess = callback;
    return this;
  }

  MontyCardPay onError(Function(dynamic response) callback){
    _onError = callback;
    return this;
  }

  MontyCardPay onPresent(Function(BuildContext context) callback){
    _onPresent = callback;
    return this;
  }


  initialize(BuildContext context){

    MontypaySdk.instance.ADAPTER.CARD_PAY.execute(
        order: _order!,
        payer: _payer!,
        callback: CardPayResponseCallback(
            success: (MontypayTransactionDetailsSuccess response){
              Log(response.toJson().toString());
              _onTransactionSuccess!(response);
            },
            failure: (MontypayTransactionDetailsSuccess response){
              Log(response.toJson().toString());
              _onTransactionFailure!(response);
            },
            error: (MontypayError error){
              _onError!(error);
            }
        ),
        onFailure: (err){

        }
    );
    Future.delayed(const Duration(milliseconds: 200)).then((value) {
      if(_onPresent != null) {
        _onPresent!(context);
      }
    });
  }

  Widget widget(){
    return const SizedBox();
  }
}