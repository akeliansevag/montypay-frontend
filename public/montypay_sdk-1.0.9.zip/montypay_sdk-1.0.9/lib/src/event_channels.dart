
import 'package:flutter/services.dart';

const SALE_EVENT_CHANNEL = "com.montypay.sdk.sale" ;
const RECURRING_SALE_EVENT_CHANNEL = "com.montypay.sdk.recurringsale";
const CAPTURE_EVENT_CHANNEL = "com.montypay.sdk.capture" ;
const CREDIT_VOID_EVENT_CHANNEL = "com.montypay.sdk.creditvoid" ;
const TRANSACTION_STATUS_EVENT_CHANNEL = "com.montypay.sdk.transactionstatus";
const TRANSACTION_DETAILS_EVENT_CHANNEL = "com.montypay.sdk.transactiondetail";
const TRANSACTION_LOGS_EVENT_CHANNEL = "com.montypay.sdk.transactionlogs";

const CARD_PAY_EVENT_CHANNEL = "com.montypay.sdk.cardpay";
const APPLE_PAY_EVENT_CHANNEL = "com.montypay.sdk.applepay";

abstract class MontypayPlatformChannels{

  final sale = const EventChannel(SALE_EVENT_CHANNEL);
  final recurringSale = const EventChannel(RECURRING_SALE_EVENT_CHANNEL);
  final capture = const EventChannel(CAPTURE_EVENT_CHANNEL);
  final creditVoid = const EventChannel(CREDIT_VOID_EVENT_CHANNEL);
  final transactionsStatus = const EventChannel(TRANSACTION_STATUS_EVENT_CHANNEL);
  final transactionsDetail = const EventChannel(TRANSACTION_DETAILS_EVENT_CHANNEL);
  final transactionsLogs = const EventChannel(TRANSACTION_LOGS_EVENT_CHANNEL);

  final cardPay = const EventChannel(CARD_PAY_EVENT_CHANNEL);
  final applePay = const EventChannel(APPLE_PAY_EVENT_CHANNEL);

}