/*
 * Property of Montypay (https://montypay.sa).
 */


/// The transaction status types.
/// @see com.montypay.sdk.model.response.gettransactiondetails.MontypayTransaction
///
/// @property transactionStatus the transaction status value.
enum MontypayTransactionStatus{
    /// Failed or "0" status.
    FAIL("fail"),

    /// Success or "1" status.
    SUCCESS("success");

    final String transactionStatus;
    const MontypayTransactionStatus(this.transactionStatus);


    factory MontypayTransactionStatus.of(String? id) {
        return values.firstWhere((e) => e.transactionStatus == id);
    }
}
