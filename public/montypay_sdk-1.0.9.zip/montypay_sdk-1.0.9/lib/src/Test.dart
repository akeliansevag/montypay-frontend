import 'Helpers.dart';

class Test{
  test(){
    Log("test");
  }
}