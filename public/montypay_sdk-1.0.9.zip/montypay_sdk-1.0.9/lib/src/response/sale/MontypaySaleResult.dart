
import 'package:montypay_sdk/montypay_sdk.dart';

class MontypaySaleResult{
  MontypaySaleSuccess? success;
  MontypaySaleRedirect? redirect;
  MontypaySale3DS? secure3d;
  MontypaySaleRecurring? recurring;
  MontypaySaleDecline? decline;
  MontypayError? error;
  dynamic failure;
  Map? responseJSON;

  MontypaySaleResult(Map result){
    if(result.containsKey("success")) {
      success = MontypaySaleSuccess.fromJson(result["success"]);
    }

    if(result.containsKey("redirect")) {
      redirect = MontypaySaleRedirect.fromJson(result["redirect"]);
    }

    if(result.containsKey("secure3d")) {
      secure3d = MontypaySale3DS.fromJson(result["secure3d"]);
    }

    if(result.containsKey("recurring")) {
      recurring = MontypaySaleRecurring.fromJson(result["recurring"]);
    }

    if(result.containsKey("decline")) {
      decline = MontypaySaleDecline.fromJson(result["decline"]);
    }

    if(result.containsKey("error")) {
      error = MontypayError.fromJson(result["error"]);
    }

    if(result.containsKey("failure")) {
      failure = result["failure"];
    }

    if(result.containsKey("responseJSON")) {
      responseJSON = result["responseJSON"];
    }
  }

  triggerCallbacks(SaleResponseCallback? callback, {Function(dynamic)? onFailure, Function(Map)? onResponseJSON}){
    if(success != null) {
      callback?.success(success!);
    }

    if(redirect != null) {
      callback?.redirect(redirect!);
    }

    if(recurring != null) {
      callback?.recurring(recurring!);
    }

    if(secure3d != null) {
      callback?.secure3d(secure3d!);
    }

    if(decline != null) {
      callback?.decline(decline!);
    }

    if(error != null) {
      callback?.error(error!);
    }

    if(failure != null && onFailure != null) {
      onFailure(failure);
    }

    if(responseJSON != null && onResponseJSON != null) {
      onResponseJSON(responseJSON ?? {});
    }
  }
}
