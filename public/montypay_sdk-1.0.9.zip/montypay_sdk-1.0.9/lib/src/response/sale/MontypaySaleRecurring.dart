import 'dart:convert';

import 'package:montypay_sdk/src/response/base/result/IDetailsMontypayResult.dart';

class MontypaySaleRecurring extends IDetailsMontypayResult{
  String? recurringToken;

  MontypaySaleRecurring.fromJson(dynamic json) : super.fromJson(json) {
    recurringToken = json['recurring_token'];
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['recurring_token'] = recurringToken;
    return map;
  }


  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
