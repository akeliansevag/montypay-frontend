import 'dart:convert';

import 'package:montypay_sdk/src/response/base/result/IDetailsMontypayResult.dart';
import 'package:montypay_sdk/src/response/sale/MontyPaySaleResponse.dart';

class MontypaySaleSuccess extends IDetailsMontypayResult with MontyPaySaleResponse{
  MontypaySaleSuccess.fromJson(dynamic json) : super.fromJson(json);

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
