import 'dart:convert';

import 'IMontypayResult.dart';

class IOrderMontypayResult extends IMontypayResult {
  /// Amount of capture.
  num?  orderAmount;

  /// Currency.
  String? orderCurrency;


  IOrderMontypayResult.fromJson(dynamic json) : super.fromJson(json) {
    orderAmount = json['amount'];
    orderCurrency = json['currency'];
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['amount'] = orderAmount;
    map['currency'] = orderCurrency;
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
