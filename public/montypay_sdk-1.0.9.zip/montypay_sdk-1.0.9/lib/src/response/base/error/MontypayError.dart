import 'dart:convert';

import 'package:montypay_sdk/src/api/MontypayResult.dart';

import 'MontypayExactError.dart';

class MontypayError {
  MontypayResult? result;
  num? errorCode;
  String? errorMessage;
  List<MontypayExactError>? errors;

  MontypayError({
      this.result, 
      this.errorCode, 
      this.errorMessage, 
      this.errors,});

  MontypayError.fromJson(dynamic json) {
    result = MontypayResult.of(json['result']);
    errorCode = json['error_code'];
    errorMessage = json['error_message'];

    if (json['errors'] != null) {
      errors = [];
      json['errors'].forEach((v) {
        errors?.add(MontypayExactError.fromJson(v));
      });
    }
  }
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['result'] = result?.result;
    map['error_code'] = errorCode;
    map['error_message'] = errorMessage;
    if (errors != null) {
      map['errors'] = errors?.map((v) => v.toJson()).toList();
    }
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }

}