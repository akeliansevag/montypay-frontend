
import 'package:montypay_sdk/src/api/MontypayTransactionStatus.dart';
import 'package:montypay_sdk/src/api/MontypayTransactionType.dart';

class MontypayTransaction {
  String? date;
  MontypayTransactionType? type;
  MontypayTransactionStatus? status;
  double? amount;
  
  MontypayTransaction({
      this.date, 
      this.type, 
      this.status, 
      this.amount,});

  MontypayTransaction.fromJson(dynamic json) {
    date = json['date'];
    type = MontypayTransactionType.of(json['type'].toString());
    status = MontypayTransactionStatus.of(json['status'].toString());
    amount = json['amount'];
  }

  Map<String?, dynamic> toJson() {
    final map = <String?, dynamic>{};
    map['date'] = date;
    map['type'] = type;
    map['status'] = status;
    map['amount'] = amount;
    return map;
  }

}