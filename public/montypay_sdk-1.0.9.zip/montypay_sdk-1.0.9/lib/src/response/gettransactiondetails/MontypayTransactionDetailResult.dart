
import 'package:montypay_sdk/montypay_sdk.dart';

class MontypayTransactionDetailResult{
  MontypayTransactionDetailsSuccess? success;
  MontypayError? error;
  dynamic failure;
  Map? responseJSON;

  MontypayTransactionDetailResult(Map result){

    if(result.containsKey("success")) {
      success = MontypayTransactionDetailsSuccess.fromJson(result["success"]);
    }

    if(result.containsKey("failure")) {
      failure = result["failure"];
    }

    if(result.containsKey("responseJSON")) {
      responseJSON = result["responseJSON"];
    }

  }

  triggerCallbacks(TransactionDetailsResponseCallback? callback, {Function(dynamic)? onFailure, Function(Map)? onResponseJSON}){
    if(success != null) {
      callback?.success(success!);
    }

    if(error != null) {
      callback?.error(error!);
    }

    if(failure != null && onFailure != null) {
      onFailure(failure);
    }


    if(responseJSON != null && onResponseJSON != null) {
      onResponseJSON(responseJSON ?? {});
    }
  }
}
