import 'dart:convert';

import 'package:montypay_sdk/src/response/base/result/IDetailsMontypayResult.dart';

class MontypayCaptureSuccess extends IDetailsMontypayResult{
  MontypayCaptureSuccess.fromJson(dynamic json) : super.fromJson(json);

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
