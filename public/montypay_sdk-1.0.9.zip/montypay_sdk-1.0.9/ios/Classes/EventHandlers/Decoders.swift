//
//  Codables.swift
//  montypay_sdk
//
//  Created by Zohaib Kambrani on 03/03/2023.
//

import Foundation
import MontyPaySDK



extension MontyPaySaleOrder{
    static func from(dictionary:[String:Any?]) -> MontyPaySaleOrder{
        return MontyPaySaleOrder(
            id: dictionary["id"] as? String ?? "",
            amount: dictionary["amount"] as? Double ?? 0.0,
            currency: dictionary["currency"] as? String ?? "",
            description: dictionary["description"] as? String ?? ""
        )
    }
}

extension MontyPayOrder{
    static func from_(dictionary:[String:Any?]) -> MontyPayOrder{
        return MontyPayOrder(
            id: dictionary["id"] as? String ?? "",
            amount: dictionary["amount"] as? Double ?? 0.0,
            description: dictionary["description"] as? String ?? ""
        )
    }
}

extension MontyPayPayer{
    static func from(dictionary:[String:Any?]) -> MontyPayPayer{
        
        return MontyPayPayer(
            firstName:  dictionary["firstName"] as? String ?? "",
            lastName: dictionary["lastName"] as? String ?? "",
            address: dictionary["address"] as? String ?? "",
            country: dictionary["country"] as? String ?? "",
            city: dictionary["city"] as? String ?? "",
            zip: dictionary["zip"] as? String ?? "",
            email: dictionary["email"] as? String ?? "",
            phone: dictionary["phone"] as? String ?? "",
            ip: dictionary["ip"] as? String ?? "",
            options: MontyPayPayerOptions.from(dictionary: dictionary["options"] as? [String : Any?])
        )
    }
}


extension MontyPayPayerOptions{
    static func from(dictionary:[String:Any?]?) -> MontyPayPayerOptions?{
        if let s = dictionary{
            return MontyPayPayerOptions(
               middleName: s["middleName"] as? String ?? "",
               birthdate: MontyPayDateFormatter().toDate(dob: s["birthdate"] as? String),
               address2: s["address2"] as? String ?? "",
               state: s["state"] as? String ?? ""
           )
        }
        return nil
        
    }
}


extension MontyPayRecurringOptions{
    static func from(dictionary:[String:Any?]) -> MontyPayRecurringOptions{
        return MontyPayRecurringOptions(
           firstTransactionId: dictionary["firstTransactionId"] as? String ?? "",
           token: dictionary["token"] as? String ?? ""
       )
    }
}

extension MontyPayCard{
    static func from(dictionary:[String:Any?]) -> MontyPayCard{
        return MontyPayCard(
            number: dictionary["number"] as? String ?? "",
            expireMonth: dictionary["expireMonth"] as? Int ?? 0,
            expireYear:  dictionary["expireYear"] as? Int ?? 0,
            cvv: dictionary["cvv"] as? String ?? ""
        )
    }
}
