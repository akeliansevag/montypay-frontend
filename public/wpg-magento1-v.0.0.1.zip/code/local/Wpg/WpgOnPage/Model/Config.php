<?php
class Wpg_WpgOnPage_Model_Config
{

    public function getAllowedMethods()
    {

        $this->writeCallbackUrl();

        $methods = [
            [
                'value' => 'card',
                'label' => 'Card',
                'selected' => true,
            ],
            [
                'value' => 'googlepay',
                'label' => 'Google Pay',
            ],
            [
                'value' => 'playpal',
                'label' => 'Pay Pal',
            ],
        ];

        return $methods;
    }

    public function getNewPaymentStatus()
    {
        $st = new Mage_Adminhtml_Model_System_Config_Source_Order_Status();
        $statuses = $st->toOptionArray();
        $right = [];
        foreach ($statuses as $status) {
            if (!in_array($status['value'], [Mage_Sales_Model_Order::STATE_COMPLETE, Mage_Sales_Model_Order::STATE_CANCELED]) ) {
                $right[$status['value']] = $status['label'];
            }
        }

        return $right;
    }

    public function getAfterPaymentStatus()
    {
        $st = new Mage_Adminhtml_Model_System_Config_Source_Order_Status();
        $statuses = $st->toOptionArray();
        $right = [];
        foreach ($statuses as $status) {
            if (!in_array($status['value'], [Mage_Sales_Model_Order::STATE_COMPLETE, Mage_Sales_Model_Order::STATE_CANCELED]) ) {
                $right[$status['value']] = $status['label'];
            }
        }

        return $right;
    }

    public function writeCallbackUrl(){
        $callback = Mage::getUrl('WpgOnPage/response', array('_secure' => true));
        Mage::getConfig()->saveConfig('payment/WpgOnPage/back_ref' , $callback);
    }

}