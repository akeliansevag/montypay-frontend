<?php

class Wpg_WpgOnPage_Block_Form extends Mage_Payment_Block_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('wpg/info.phtml');
    }

    protected function _toHtml()
    {
        return parent::_toHtml();
    }

    public function getDesc()
    {
        /** @var Wpg_WpgOnPage_Model_WpgOnPage */
        $payment = Mage::getModel('WpgOnPage/WpgOnPage');
        return $payment->getConfigData('desc');
    }
}
